
document.getElementById("left").href = "overview.html";
document.getElementById("right").href = "idealisation.html";