
document.getElementById('navigator').innerHTML='<a id="oright" class="nav"><img src="images/nav_icon.webp"></a><a id="oleft" class="nav"><img src="images/nav_icon.webp"></a>'

document.getElementById("oleft").href = "index.html";
document.getElementById("oright").href = "reality.html";